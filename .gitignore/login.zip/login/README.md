# php-PDO-and-jQuery-AJAX

PHP PDO and jQuery AJAX tutorial source code

Programmer Blog: http://programmerblog.net

## Steps to perform this tutorial

1. Create a database onlinestore

2. Create a table for products

3. Display products from mysql database on view page.

4. Add records to MySQL database using jQuery AJAX

5. Edit records in database using php PDO and jQuery AJAX

6. Delete records from database using php PDO and jQuery AJAX


You can read detailed tutorial at:

http://programmerblog.net/php-pdo-ajax-tutorial-example/
