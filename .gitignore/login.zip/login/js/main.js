$(function () {

     /* Delete button ajax call */
     $('.delbtn').on('click', function () {
          if (confirm('Diese Aktion löscht diesen Datensatz. Bist du sicher?')) {
               var pid = $(this).data('pid');
               $.post("delete_ajax.php", {
                    pid: pid
               })
                    .done(function (data) {
                         if (data > 0) {
                              $('.success').show(3000).html("Datensatz erfolgreich gelöscht.").delay(3200).fadeOut(6000);
                         } else {
                              $('.error').show(3000).html("Datensatz konnte nicht gelöscht werden. Bitte versuche es erneut.").delay(3200).fadeOut(6000);;
                         }
                         setTimeout(function () {
                              window.location.reload(2);
                         }, 5000);
                    });
          }
     });

     /* Edit button ajax call */
     $('.editbtn').on('click', function () {
          var pid = $(this).data('pid');
          $.get("getrecord_ajax.php", {
               id: pid
          })
               .done(function (product) {
                    data = $.parseJSON(product);

                    if (data) {
                         $('#prod_id').val(data.id);
                         $('#product_name').val(data.product_name);
                         $('#price').val(data.price);
                         $('#article').val(data.article);
                         $('#category').val(data.category);
                         $("#saverecords").val('Save Records');
                    }
               });
     });

     /* Edit button ajax call */
     $('#saverecords').on('click', function () {
          var prod_id = $('#prod_id').val();
          var product = $('#product_name').val();
          var price = $('#price').val();
          var article = $('#article').val();
          var category = $('#category').val();
          if (!product || !price || !article || !category) {
               $('.error').show(3000).html("Alle Felder sind erforderlich.").delay(3200).fadeOut(3000);
          } else {
               if (prod_id) {
                    var url = 'edit_record_ajax.php';
               } else {
                    var url = 'add_records_ajax.php';
               }
               $.post(url, {
                    prod_id: prod_id,
                    product: product,
                    category: category,
                    price: price,
                    article: article
               })
                    .done(function (data) {
                         if (data > 0) {
                              $('.success').show(3000).html("Datensatz erfolgreich gespeichert.").delay(2000).fadeOut(1000);
                         } else {
                              $('.error').show(3000).html("Datensatz konnte nicht gespeichert werden. Bitte erneut versuchen.").delay(2000).fadeOut(1000);
                         }
                         $("#saverecords").val('Add Records');
                         setTimeout(function () {
                              window.location.reload(1);
                         }, 15000);
                    });
          }
     });
});