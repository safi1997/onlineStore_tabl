<?php

require_once('dbconn.php');

$sth = $dbconn->prepare("SELECT `id`, `product_name`, `price`, `category` FROM tbl_products order by id desc");
$sth->execute();
/* Fetch all of rows in the result set */
$result = $sth->fetchAll();

?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/main.css">
</head>
<body>
  <div class="container">
    <h2>Fetch and view records using php PDO methods</h2>
    <div class="success"></div>
    <div class="error"></div>
    <h2>Add / Edit Records</h2>
    <form>
       <table>
        <tr>
          <td colspan="4" style="text-align: center">
            <input type="hidden" id ='prod_id' value='' />
            <input type="hidden" id ='prod_id' value='' />
            <input type='text' id='product_name' placeholder='Product' required />&nbsp;&nbsp;
          <input type='text' id='price' placeholder='Price' required />&nbsp;&nbsp;
          <input type='text' id='article' placeholder='Article' required />&nbsp;&nbsp;
          <input type='text' id='category' placeholder='Category' required />&nbsp;&nbsp;
          <input type='button' id='saverecords'  value ='Add Records' /></td>
        </tr>
      </table>
    </form>
    <h2>View Records</h2>
    <table>
      <tr>
        <th>#</th>
        <th>Product Name</th>
        <th>Price</th>
        <th>Article</th>
        <th>Category</th>
        <th>Action</th>
      </tr>
  <?php
  /* FetchAll foreach with edit and delete using Ajax */
  if($sth->rowCount()):
   foreach($result as $row){ ?>
     <tr>
       <td><?php echo $row['id']; ?></td>
       <td><?php echo $row['product_name']; ?></td>
       <td><?php echo $row['price']; ?></td>
       <td><?php echo $row['article']; ?></td>
       <td><?php echo $row['category']; ?></td>
       <td><a data-pid = <?php echo $row['id']; ?> class='editbtn' href= 'javascript:void(0)'>Edit
        </a>&nbsp;|&nbsp;<a class='delbtn' data-pid=<?php echo $row['id']; ?> href='javascript:void(0)'>Delete</a></td>
     </tr>
   <?php }  ?>
  <?php endif;  ?>
  </table>
  </div>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
 <script src="js/main.js"></script> 
  </body>
</html>